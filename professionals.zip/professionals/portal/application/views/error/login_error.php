<div class="container">
    <div class="row">
    <div class="col-md-5 center-block-e">

<div class="login-page-header">
 <?php echo lang("ctn_133") ?>

</div>
<div class="login-page">
<b><?php echo lang("ctn_134") ?>:</b> <?php echo $message ?>
<p><input type="button" value="<?php echo lang("ctn_135") ?>" onclick="window.history.back()" class="btn btn-default btn-sm" /> </p>
</div>

</div>
</div>
</div>