<div class="container">
    <div class="row">
    <div class="col-md-5 center-block-e">

      

      <div class="login-form">
      	<div class="login-form-inner">
		<h2><?php echo lang("ctn_172") ?></h2>



	<?php echo lang("ctn_173") ?>
</div>
	</div>

</div>
</div>
</div>