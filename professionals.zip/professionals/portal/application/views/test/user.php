<div class="white-area-content">

<div class="db-header clearfix">
    <div class="page-header-title"> <span class="glyphicon glyphicon-user"></span> User Page</div>
    <div class="db-header-extra"> 
</div>
</div>

<ol class="breadcrumb">
  <li><a href="<?php echo site_url() ?>">Home</a></li>
  <li class="active">User Page</li>
</ol>

<p>This is an example of a page in which only the user with the username Admin can view.</p>
<hr>

<p>You can easily restrict access to users with certain usernames. Just check out the code inside the file application/controllers/Test.php</p>
</div>