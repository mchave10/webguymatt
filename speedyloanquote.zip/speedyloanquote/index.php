<!DOCTYPE html>

<html lang="en-US">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name='robots' content='noindex,follow'>
  
  <!-- Page Title -->
  <title>Speedy Loan Quote - </title>
  
  <!-- Favicons -->
  <link rel="icon" type="image/png" href="assets/images/favicon.png">
  
  <!-- Apple touch icon -->
  <link rel="apple-touch-icon" href="assets/images/apple-touch-icon-120x120.png">
  
  <!-- Bootstrap Styles -->
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" type="text/css" media="all">
  
  <!-- Component Styles -->
  <link rel="stylesheet" href="assets/mtphr-slider/mtphr-slider.css" type="text/css" media="all">
  <link rel="stylesheet" href="assets/mtphr-slidegraph/mtphr-slidegraph.css" type="text/css" media="all">
  <link rel="stylesheet" href="assets/mtphr-gallery/mtphr-gallery.css" type="text/css" media="all">
  <link rel="stylesheet" href="assets/mtphr-rotator/mtphr-rotator.css" type="text/css" media="all">
  
  <!-- Animate Styles -->
	<link rel="stylesheet" href="assets/css/animate.min.css" type="text/css" media="all">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  
  <!-- Apex Styles -->
  <link rel="stylesheet" href="assets/fontastic/styles.css" type="text/css" media="all">
  <link rel="stylesheet" href="assets/css/main.css?v=1.0.8" type="text/css" media="all">
  
  <!-- Custom Styles -->
  <link rel="stylesheet" href="assets/css/custom.css" type="text/css" media="all">

  <!-- Load Modernizr -->
  <script type="text/javascript" src="assets/js/modernizr-2.6.2.min.js"></script>
  
  <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/js/respond.min.js"></script>
  <![endif]-->
  
  

</head>

<body class="apex-hide-nav apex-menu-scroll">


	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<!-- !Hero element -->
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	
	<div id="apex-hero">
	  <div id="apex-hero-inner">
	  
	  	<!-- The hero background rotator -->
	    <div id="hero-bg-rotator" class="mtphr-rotator">
	      <div class="mtphr-rotator-resource-container">
					<div id="home-slide-1" class="mtphr-rotator-resource" data-mtphr-parallax-speed="6"></div>
	        <div id="home-slide-2" class="mtphr-rotator-resource" data-mtphr-parallax-speed="6"></div>
	        <div id="home-slide-3" class="mtphr-rotator-resource" data-mtphr-parallax-speed="6"></div>
	      </div>
	    </div>
	     
	    <!-- Background gradient overlay --> 
	    <div id="apex-hero-gradient"></div>
	    
	    <!-- Background pattern overlay --> 
	    <div id="apex-hero-overlay"></div>
	
	    <div class="container">
	      <div class="apex-hero-content">
	          
	        <!-- The hero logo -->
	        <div id="hero-logo" class="apex-hero-element">
	          <a href="/">
	          	<img src="assets/images/logo.png" alt="Speedy Loan Quote">
	        	</a>
	        </div>
					
					<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
					<!-- !Start Mtphr Rotator -->
					<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
					
	        <div id="hero-rotator" class="mtphr-rotator apex-hero-element">
	          <div class="mtphr-rotator-resource-container">
	            <div class="mtphr-rotator-resource">#1 Online Resource for Loans</div>
	            <div class="mtphr-rotator-resource">Apply online in minutes</div>
	            <div class="mtphr-rotator-resource">Your Future is in your hands</div>
	          </div>
						<div class="mtphr-rotator-navigation">
							<a href="#0" rel="nofollow"><i class="apex-icon-circle"></i><i class="apex-icon-circle-blank"></i></a>
							<a href="#1" rel="nofollow"><i class="apex-icon-circle"></i><i class="apex-icon-circle-blank"></i></a>
							<a href="#2" rel="nofollow"><i class="apex-icon-circle"></i><i class="apex-icon-circle-blank"></i></a>
						</div>
	        </div>
	        
	        <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
					<!-- !End Mtphr Rotator -->
					<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
					
					<!-- The hero menu -->
	        <nav class="apex-hero-menu-container apex-hero-element">
	          <ul class="clearfix">
	            <li><a href="#about"><i class="apex-icon-dollars"></i>Personal Loans</a></li>
	            <li><a href="#team"><i class="fa fa-home" aria-hidden="true"></i>Home Purchase</a></li>
	            
	            <li><a href="#portfolio"><i class="apex-icon-dollar-coins"></i>Home Refinance</a></li>
	            <li><a href="blog.html"><i class="apex-icon-sign-open"></i>Business Loans</a></li>
	            <li><a href="#contact"><i class="apex-icon-truck"></i>Auto Loans</a></li>
                <li><a href="#services"><i class="apex-icon-members"></i>Life Insurance</a></li>  
	          </ul>
	        </nav>
	          
	      </div><!-- .apex-hero-content -->
	    </div><!-- .container -->
	      
	  </div><!-- #apex-hero-inner -->
	</div><!-- #apex-hero -->
		
		
		
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<!-- !Site navigation -->
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	
 <!-- <header id="site-navigation">
    <div id="site-navigation-contents">
      <div class="container">
      
      
        <a id="logo" href="/">
        	<img src="assets/images/logo.png" alt="Apex" width="75" height="21">
      	</a>
      	
      	<a id="mobile-menu-toggle" href="#"><i class="apex-icon-mobile-menu"></i></a>
				
		
        <nav class="apex-primary-menu-container">
          <ul>
            <li class="hidden-xs"><a href="index.html">Home</a></li>
            <li><a href="#about"><i class="apex-icon-gear"></i>About</a></li>
            <li><a href="#team"><i class="apex-icon-members"></i>Team</a></li>
            <li><a href="#services"><i class="apex-icon-speech-bubble-4"></i>Services</a></li>
            <li><a href="#portfolio"><i class="apex-icon-polaroid-1"></i>Portfolio</a></li>
            <li>
            	<a href="blog.html"><i class="apex-icon-write"></i>Blog</a>
							<ul>
								<li>
									<a href="post-text.html">
										<span class="sub-menu-arrow"></span>
										<i class="apex-icon-circle"></i>
										Text Post
									</a>
								</li>
								<li>
									<a href="post-single-image.html">
										<span class="sub-menu-arrow"></span>
										<i class="apex-icon-circle"></i>
										Image Post
									</a>
								</li>
								<li>
									<a href="post-multiple-image.html">
										<span class="sub-menu-arrow"></span>
										<i class="apex-icon-circle"></i>
										Multi-Image Post
									</a>
								</li>
								<li>
									<a href="post-video.html">
										<span class="sub-menu-arrow"></span>
										<i class="apex-icon-circle"></i>
										Video Post
									</a>
								</li>
							</ul>
            </li>
            <li><a href="#contact"><i class="apex-icon-plane-2"></i>Contact</a></li>
          </ul>
        </nav>
        
      </div>
    </div>
  </header><!-- #site-header -->
  
  
  <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<!-- !Main wrapper -->
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->

  <div id="wrapper">
	    
	    
	    
	  <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
		<!-- !Main content -->
		<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	
	  <div id="main" role="main">
	  	
	  	
	  	
	  	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !Start section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			
		  <section id="about" class="apex-section">
		    
		    <!-- Background pattern overlay -->
		  	<div class="apex-section-overlay"></div>
		
	      <div class="apex-section-inner">      
	        <div class="container">
	              
		        <article>
		        
		          <div class="entry-content clearfix">
		          
		            <div class="row">
		          <h3 class="section-title text-center" style="margin-bottom: 46px;text-transform:none;font-size: 36px;padding:15px 15px">The Best Lending Resources at Your Fingertips</h1>    
		              <div class="col-sm-3 wow fadeIn">
		                
		                <p class="text-center small-margin">
		                	<!-- Start round icon -->
		                	<a href="#" class="apex-icon-round">
		                		<span class="apex-icon">
		                			<i class="apex-icon-download"></i>
		                		</span>
		                		<span class="apex-icon-title">Choose Loan Type</span>
		              		</a>
		              		<!-- End round icon -->
		                </p>
		
		                <p class="text-center">
		                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.
		                	<br/>
			                <a class="apex-readmore" href="#apex-hero">Choose Loan Type</a>
		                </p>
		                
		              </div>
		              
		              <div class="col-sm-3 wow fadeIn" data-wow-delay=".25s">
		              
		              	<p class="text-center small-margin">
		                	<!-- Start round icon -->
		                	<a href="#" class="apex-icon-round">
		                		<span class="apex-icon">
		                			<i class="apex-icon-ipad"></i>
		                		</span>
		                		<span class="apex-icon-title">Apply Online</span>
		              		</a>
		              		<!-- End round icon -->
		                </p>
		
		                <p class="text-center">
		                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.
		                	<br/>
			                <a class="apex-readmore" href="#apex-hero">Choose Loan Type</a>
		                </p>
		                
		              </div>
		
		              <div class="col-sm-3 wow fadeIn" data-wow-delay=".5s">
		              
		              	<p class="text-center small-margin">
		                	<!-- Start round icon -->
		                	<a href="#" class="apex-icon-round">
		                		<span class="apex-icon">
		                			<i class="apex-icon-compass"></i>
		                		</span>
		                		<span class="apex-icon-title">Receive Quote</span>
		              		</a>
		              		<!-- End round icon -->
		                </p>
		
		                <p class="text-center">
		                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.
		                	<br/>
			                <a class="apex-readmore" href="#apex-hero">Choose Loan Type</a>
		                </p>
		                
		              </div>
		
		              <div class="col-sm-3 wow fadeIn" data-wow-delay=".75s">
		              
		              	<p class="text-center small-margin">
		                	<!-- Start round icon -->
		                	<a href="#" class="apex-icon-round">
		                		<span class="apex-icon">
		                			<i class="apex-icon-tea"></i>
		                		</span>
		                		<span class="apex-icon-title">Achieve Your Goals</span>
		              		</a>
		              		<!-- End round icon -->
		                </p>
		
		                <p class="text-center">
		                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.
		                	<br/>
			                <a class="apex-readmore" href="#apex-hero">Choose Loan Type</a>
		                </p>
		                
		              </div>
		              
		            </div><!-- .row -->
		            
		          </div><!-- .entry-content -->
		          
		        </article>
	              
	        </div><!-- .container -->
	      </div><!-- .apex-section-inner -->
		  </section><!-- .apex-section -->
		  
		  <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !End section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	      
	      
	      
	    <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !Start section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<!--
	    <section class="apex-section apex-style-light">
	    

	      <div class="apex-section-overlay"></div>
	
	      <div class="apex-section-inner">
	        <div class="container">
	              
		        <article>
		        
		          <div class="entry-content clearfix">
		          
		            <div class="row">
		            
		              <div class="col-sm-6 col-md-5 col-md-offset-1 wow fadeIn">
		                <p><img class="aligncenter" src="assets/images/phone.png" alt="phone" width="414" height="283"></p> 
		              </div>
		
		              <div class="col-sm-6 col-md-5 wow fadeIn" data-wow-delay=".25s">
		                <h1 class="light">Responsive Design</h1>
		                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
		                <p><a href="#" class="btn">Choose Loan Type</a></p>
		              </div>
		              
		            </div>
		            
		          </div>
		          
		        </article>
	
	        </div>
	      </div>
	    </section><!-- .apex-section -->
	    
	    <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !End section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	
	
	    
	    <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !Start section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	    <!-- 
	    <section id="quotes" class="apex-section apex-style-dark apex-style-wide" data-mtphr-parallax-speed="6">
	      

	      <div class="apex-section-overlay"></div>
	
	      <div class="apex-section-inner">
	        <div class="container">
	        
	 
						
	          <div id="apex-rotator-quotes" class="mtphr-rotator wow fadeIn">

              <div class="mtphr-rotator-resource-container">

             
                <div class="mtphr-rotator-resource apex-format-quote">
	                <div class="entry-featured">
		                <i class="apex-icon-quotes"></i>
	                </div>
	                <div class="entry-content clearfix">
	                  <p>We realize and actualize your vision</p>
	                </div>
	                <div class="entry-title">APEX Mission Statement</div>
                </div>
        
                <div class="mtphr-rotator-resource apex-format-quote">
	                <div class="entry-featured">
		                <i class="apex-icon-quotes"></i>
	                </div>
	                <div class="entry-content clearfix">
	                  <p>We realize and actualize your vision</p>
	                </div>
	                <div class="entry-title">APEX Mission Statement</div>
                </div>
           
                <div class="mtphr-rotator-resource apex-format-quote">
	                <div class="entry-featured">
		                <i class="apex-icon-quotes"></i>
	                </div>
	                <div class="entry-content clearfix">
	                  <p>We realize and actualize your vision</p>
	                </div>
	                <div class="entry-title">APEX Mission Statement</div>
                </div>
         
  
              </div>
	            
	
              <div class="mtphr-rotator-footer">
	              <a class="mtphr-rotator-nav-prev" href="#" rel="nofollow"><i class="apex-icon-arrow-left-1"></i></a>
	              <a class="mtphr-rotator-nav-next" href="#" rel="nofollow"><i class="apex-icon-arrow-right-1"></i></a>
              </div>
        
              
	          </div>
	          
	
	
	        </div>
	      </div>
	    </section><!-- .apex-section -->
	    
	    <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !End section -->
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			
			
			
			<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
			<!-- !Start section
			
	    <section id="team" class="apex-section">
	    	

	      <div class="apex-section-overlay"></div>
	
	      <div class="apex-section-inner">
	        <div class="container">
	            
		        <article>
		        	
		        	
		          <div class="section-header wow fadeIn">
		            <h1 class="section-title">Our Team</h1>
		            <div class="section-header-sep"><span></span></div>
		            <h4 class="section-tagline">Meet the faces behind our company</h4>
		          </div>
		     
		
		          <div class="entry-content wow fadeIn" data-wow-delay=".25s">
		          
		        
								
		            <div class="mtphr-slider">
		            	
		            	
		              <div class="mtphr-slider-header">
		                <div class="mtphr-slider-navigation clearfix">
		                  <a class="mtphr-slider-prev" href="#">
		                    <i class="apex-icon-arrow-left-1"></i>
		                  </a>
		                  <a class="mtphr-slider-next" href="#">
		                    <i class="apex-icon-arrow-right-1"></i>
		                  </a>
		                </div>
		              </div>
		
		              <div class="mtphr-slider-content-wrapper">
		                <div class="mtphr-slider-content clearfix">
		                  
		
		                  <div class="mtphr-slider-block apex-format-member">
		                    <div class="entry-header">
		                      <div class="entry-featured-archive">
		                          <img src="assets/images/Team1.jpg" alt="Team 1" width="370" height="280">
		                          <span class="entry-featured-overlay">
		                          	<span class="entry-featured-icons-container">
		                          		<span class="entry-featured-icons entry-featured-icons-8 clearfix">
		                          			<a href="http://www.android.com" target="_blank">
		                            			<i class="apex-icon-android"></i>
		                          			</a>
		                          			<a href="http://paypal.com" target="_blank">
		                            			<i class="apex-icon-paypal"></i>
		                          			</a>
		                          			<a href="http://vimeo.com" target="_blank">
		                            			<i class="apex-icon-vimeo"></i>
		                          			</a>
		                          			<a href="http://www.behance.com" target="_blank">
		                            			<i class="apex-icon-behance"></i>
		                          			</a>
		                          			<a href="http://www.evernote.com" target="_blank">
		                            			<i class="apex-icon-evernote"></i>
		                          			</a>
		                          			<a href="http://amazon.com" target="_blank">
		                            			<i class="apex-icon-amazon"></i>
		                          			</a>
		                          			<a href="http://www.msn.com" target="_blank">
		                            			<i class="apex-icon-msn"></i>
		                          			</a>
		                          			<a href="http://grooveshark.com" target="_blank">
		                            			<i class="apex-icon-grooveshark"></i>
		                          			</a>
		                        			</span>
		                      			</span>
		                    			</span>
		                    			<span class="entry-featured-data clearfix">
		                    				<span class="entry-title">John Doe</span>
		                    				<span class="entry-data">Chief Executive Officer</span>
		                    				<a class="entry-featured-overlay-toggle" href="#">+</a>
		                  				</span>
		                      </div>
		                    </div>
		                    <div class="entry-excerpt">
		                      <p>
		                      	Urna nulla proin. Sapien quam urna. Non vitae congue justo nonummy eu turpis pharetra at cursus fusce vitae rutrum libero euismod ornare at&hellip;
		                      	<br/>
		                      	<a class="apex-readmore" href="#">Read more</a> 
		                      </p>     
		                    </div>
		                  </div>
		                  <!-- End slider block -->
		                  
		              
	  </div><!-- #main -->
  


		<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
		<!-- !Site Footer -->
		<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
		
	  <footer id="site-footer" role="contentinfo">
	    <div class="container">
	      <div class="row">
	      
	        <div id="apex-social-links" class="col-sm-6 col-sm-push-6 clearfix">
		        <div class="wrapper clearfix">
		      
	
		        </div>
	        </div><!-- #apex-social-links -->
	
	        <div id="apex-copyright" class="col-sm-6 col-sm-pull-6">
		        <div class="wrapper clearfix">
	            <p>Copyright © <?php echo date('Y'); ?> Speedy Loan Quote. All Rights Reserved.<br></p>
		        </div>
	        </div><!-- #apex-copyright -->
	          
	      </div><!-- .row -->
	      
	      <a id="apex-totop" href="#"><i class="apex-icon-arrow-up-short"></i></a>
	      
	    </div><!-- .container -->
	  </footer><!-- #site-footer -->



  </div><!-- #wrapper -->
  
  
  
  
  <a id="apex-totop-float" href="#"><i class="apex-icon-arrow-up"></i></a>
  



	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<!-- !Footer scripts -->
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	
	<!-- Load jQuery -->
  <script type="text/javascript" src="assets/js/jquery-1.11.1.min.js"></script>
	
	<!-- Load Ajax Form script -->
	<script type="text/javascript" src="assets/js/jquery.form.min.js"></script>
	
	<!-- Load Validate script -->
	<script type="text/javascript" src="assets/validate/jquery.validate.min.js"></script>
	
	<!-- Load jQuery easing script -->   
	<script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
	
	<!-- Load Bootstrap script -->
	<!-- <script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script> -->
	
	<!-- Load Respond script -->
	<script type="text/javascript" src="assets/js/respond.min.js"></script>
	
	<!-- Load Touch Swipe script -->
	<script type="text/javascript" src="assets/js/jquery.touchSwipe.min.js"></script>
	
	<!-- Load Parallax script -->
	<script type="text/javascript" src="assets/mtphr-parallax/mtphr-parallax.js"></script>
	
	<!-- Load Metaphor Slider script -->
	<script type="text/javascript" src="assets/mtphr-slider/mtphr-slider.js"></script>
	
	<!-- Load Metaphor Slide Graph script -->
	<script type="text/javascript" src="assets/mtphr-slidegraph/mtphr-slidegraph.js"></script>
	
	<!-- Load Metaphor Gallery & Isotope scripts -->
	<script type="text/javascript" src="assets/js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.isotope.perfectmasonry.js"></script>
	<script type="text/javascript" src="assets/mtphr-gallery/mtphr-gallery.js"></script>
	<script type="text/javascript" src="assets/mtphr-rotator/mtphr-rotator.js"></script>
	
	<!-- Load WOW scripts -->
	<script type="text/javascript" src="assets/js/wow.min.js"></script>
	
	<!-- Load Apex scripts -->
	<script type="text/javascript" src="assets/js/script.js"></script>
	
	

	<script type="text/javascript">
		
		jQuery( document ).ready( function($) {
			
			// Setup strict mode
			(function() {
		
		    "use strict";



				/* --------------------------------------------------------- */
				/* !Setup parallax elements */
				/* --------------------------------------------------------- */
				
				$('html.no-touch #hero-bg-rotator').find('.mtphr-rotator-resource').mtphr_parallax();
				$('html.no-touch #quotes').mtphr_parallax();
				$('html.no-touch #tweets').mtphr_parallax();
				$('html.no-touch #services-more').mtphr_parallax();
				$('html.no-touch #client-quotes').mtphr_parallax();
				
				
				/* --------------------------------------------------------- */
				/* !Setup the hero bg rotator as soon as possible */
				/* --------------------------------------------------------- */
				
				$( '#hero-bg-rotator' ).mtphr_rotator({
		      type : 'rotate',
		      rotate_type : 'fade',
		      rotate_ease : 'easeInOutQuint',
		      nav_reverse : 1,
			  });
			  
			  
			  /* --------------------------------------------------------- */
				/* !Setup WOW */
				/* --------------------------------------------------------- */
			
				var wow = new WOW({
					offset: 150,
					mobile: false
				});
				wow.init();
				
				
				/* --------------------------------------------------------- */
				/* !Setup the galleries */
				/* --------------------------------------------------------- */
			
				$('.mtphr-gallery').mtphr_gallery();
	
	
				/* --------------------------------------------------------- */
				/* !Setup the contact form validation */
				/* --------------------------------------------------------- */
	
				$('#contact-form').validate({
					errorClass: 'apex-error',
					validClass: 'apex-valid',
					errorElement: 'div',
					submitHandler: function(form) {
						$(form).find('button[type="submit"]').addClass('loading');
				    $(form).ajaxSubmit({
					    target: '#contact-form-response',
					    clearForm: true,
							resetForm: true,
							success: function() {
								$(form).find('button[type="submit"]').removeClass('loading');
							}
				    });
				  }
				});
			
			}());

		});
		
		jQuery( window ).load( function() {
		
			// Setup strict mode
			(function() {
		
		    "use strict";
				
	
				/* --------------------------------------------------------- */
				/* !Setup the rotators */
				/* --------------------------------------------------------- */
	
	    	jQuery( '#hero-rotator' ).mtphr_rotator({
		      rotate_type : 'slide_up',
		      auto_rotate : 1,
		      rotate_delay : 7,
		      rotate_ease : 'easeInOutQuint',
		      nav_reverse : 1,
			  });
	
		  	jQuery( '#apex-rotator-quotes, #apex-rotator-tweets, #apex-rotator-client-quotes' ).mtphr_rotator({
		      rotate_type : 'slide_left',
		      auto_rotate : 1,
		      rotate_delay : 7,
		      rotate_ease : 'easeInOutQuint',
		      nav_reverse : 1,
			  });
			  
			  /* --------------------------------------------------------- */
			  /* !Setup the hero rotator listener */
			  /* --------------------------------------------------------- */
			  
			  $( '#hero-rotator' ).on('mtphr_rotator_before_change_single', function( e, vars ) {
					$( '#hero-bg-rotator' ).trigger('mtphr_rotator_goto', [vars.next]);
				});
				
				
				/* --------------------------------------------------------- */
				/* !Setup the sliders */
				/* --------------------------------------------------------- */
				
				jQuery('.mtphr-slider').mtphr_slider({
				  slide_speed : 1000
			  });
			  
			  
			  
			  /* --------------------------------------------------------- */
			  /* !Setup the slide graphs */
			  /* --------------------------------------------------------- */
			  
				jQuery( '.mtphr-slidegraph' ).mtphr_slidegraph();
			
			}());
	
		});
		
	</script>
    

</body>
</html>
