=== Apex Responsive HTML Theme - 1.0.8 ===


== Changelog ==

= 1.0.8 =
* Added simple antispam implementation to form

= 1.0.7 =
* Updated touchSwipe.js
* Fixed inactive links on mobile using touchSwipe

= 1.0.6 =
* Added SMTP email option

= 1.0.5 =
* Added sub menu to main menu

= 1.0.4 =
* Fixed bug in script.js file that was affecting the mobile menu

= 1.0.3 =
* Added additional scroll to top button
* CSS updates

= 1.0.2 =
* Fixed javascript issue when adding external link to primary menu

= 1.0.1 =
* Javascript adjustment for hidden menu
* Removed code from the mail script that was meant for preview mode only

= 1.0.0 =
* Added simple antispam implementation to form.